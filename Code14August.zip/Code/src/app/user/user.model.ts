export interface IUser{
    Id:number;
    UserName:string;
    FirstName:string;
    LastName:string;
}