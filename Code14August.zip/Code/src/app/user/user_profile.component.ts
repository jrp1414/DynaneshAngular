import {Component} from "@angular/core"

@Component({
    moduleId:module.id,
    templateUrl:"user_profile.component.html"
})
export class ProfileComponent{

}