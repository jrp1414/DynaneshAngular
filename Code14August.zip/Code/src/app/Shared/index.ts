export * from "./error404.component";
export * from "./star.component";