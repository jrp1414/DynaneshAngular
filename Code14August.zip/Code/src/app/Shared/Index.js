"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./error404.component"));
__export(require("./star.component"));
//# sourceMappingURL=Index.js.map