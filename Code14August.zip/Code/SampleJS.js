﻿function myfunction() {
    if (number>10) {
        let x = true;
    }

    console.log(x);
}